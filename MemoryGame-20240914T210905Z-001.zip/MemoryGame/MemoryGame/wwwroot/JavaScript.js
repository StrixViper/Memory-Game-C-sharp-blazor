﻿function flipCard(card) {
    card.querySelector('.card-inner').classList.toggle('clicked');
}